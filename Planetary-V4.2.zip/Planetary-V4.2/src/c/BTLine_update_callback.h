#ifndef BTLine_update_callback_h
#define BTLine_update_callback_h


void BTLine_update_callback(Layer *BTLayer, GContext* BT1ctx);
 
#endif